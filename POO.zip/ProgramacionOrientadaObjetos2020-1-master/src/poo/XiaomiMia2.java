/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class XiaomiMia2 {
    private String marca;
   private int tamano;
   private double peso;   
   
   public XiaomiMia2(){};

public XiaomiMia2(int x){
    tamano=x;
}
public void setXiaomiMia2(int x){
    this.tamano=x;
}

public String getXiaomiMia2(){
    return this.marca;
} 
}