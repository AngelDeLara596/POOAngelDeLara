/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class FordFiesta2009 {
       public String marca;
   public int tamano;
   public double peso;
public FordFiesta2009(){};

public void FordFista2009(int x){
    tamano=x;
};

}
