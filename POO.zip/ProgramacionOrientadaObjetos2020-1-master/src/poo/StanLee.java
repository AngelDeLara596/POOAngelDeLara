/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class StanLee {
    private String marca;
   private int tamano;
   private double peso;

public StanLee(){};

public StanLee(int x){
    tamano=x;
};
public void setStanLee(int x){
    this.tamano=x;
}

public String getStanLee(){
    return this.marca;
} 
}
