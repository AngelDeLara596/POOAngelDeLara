/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class TarjetaDeVideo {
    public String marca;
   public int tamano;
   public double peso;

public TarjetaDeVideo(){};

public TarjetaDeVideo(int x){
    tamano=x;
};   
}
