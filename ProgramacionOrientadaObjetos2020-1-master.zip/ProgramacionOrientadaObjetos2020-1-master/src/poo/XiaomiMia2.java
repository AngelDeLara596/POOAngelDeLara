/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class XiaomiMia2 {
    public String marca;
   public int tamano;
   public double peso;   
   
   public XiaomiMia2(){};

public XiaomiMia2(int x){
    tamano=x;
}
}