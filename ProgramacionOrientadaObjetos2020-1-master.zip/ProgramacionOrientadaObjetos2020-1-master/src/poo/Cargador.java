/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class Cargador {
   public String textura;
   public int tamano;
   public double peso;

public Cargador(){};

public Cargador(int x){
    tamano=x;
};

}
